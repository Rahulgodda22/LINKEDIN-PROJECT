# Static-LinkedIn-Page
It is A static LinkedIn Page 
I have used html And css for this project , no bootstarp here 
